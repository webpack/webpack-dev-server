// webpack's own console logger. The one thing left out is
// `webpack/lib/logging/runtime.js`, which is a few lines of glue around these
// two and a `tapable` hook for plugins to intercept messages with: the client
// has no plugins, and `tapable` asks for `util` and compiles its hooks with
// `new Function`. In a `universal` or `["web", "node"]` build that put a
// `createRequire` of a node builtin in the page's bundle, which a page cannot
// call, and a `require-trusted-types-for 'script'` policy refused the hooks.

// @ts-expect-error -- no published types for these entry points
import { Logger } from "../modules/logger/Logger.cjs";
// @ts-expect-error -- no published types for these entry points
import createConsoleLogger from "../modules/logger/createConsoleLogger.cjs";
var DEFAULT_NAME = "webpack-dev-middleware";
var DEFAULT_LEVEL = "info";

/** @typedef {false | true | "none" | "error" | "warn" | "info" | "log" | "verbose"} LogLevel */

/** @type {{ level: LogLevel, debug: boolean, console: Console }} */
var options = {
  level: DEFAULT_LEVEL,
  debug: false,
  console: console
};
var consoleLogger = createConsoleLogger(options);

/**
 * @param {LogLevel} level log level (or `false` for off, `true` for default)
 */
export function setLogLevel(level) {
  options.level = level;
  consoleLogger = createConsoleLogger(options);
}

// What every message is labelled with in the console. A package embedding this
// runtime is the package the developer installed and the one they would report
// a problem to, so it says its own name rather than this one.
var loggerName = DEFAULT_NAME;

/**
 * @param {string=} name what to label messages with
 */
export function setLogName(name) {
  loggerName = name || DEFAULT_NAME;
}
var rawLog = new Logger(
/**
 * @param {string} type what kind of message it is
 * @param {unknown[]} args what was logged
 */
function (type, args) {
  consoleLogger(loggerName, type, args);
});
export var log = {
  /**
   * @param {...unknown} args what to log
   */
  error: function error() {
    rawLog.error.apply(rawLog, arguments);
  },
  /**
   * @param {...unknown} args what to log
   */
  warn: function warn() {
    rawLog.warn.apply(rawLog, arguments);
  },
  /**
   * @param {...unknown} args what to log
   */
  info: function info() {
    rawLog.info.apply(rawLog, arguments);
  },
  /**
   * @param {...unknown} args what to log
   */
  log: function log() {
    rawLog.log.apply(rawLog, arguments);
  },
  /**
   * @param {...unknown} args what to log
   */
  groupCollapsed: function groupCollapsed() {
    rawLog.groupCollapsed.apply(rawLog, arguments);
  },
  groupEnd: function groupEnd() {
    rawLog.groupEnd();
  }
};