/**
 * Put the token on an endpoint url.
 *
 * On the url because neither `EventSource` nor `WebSocket` lets a page set a
 * request header, so there is nowhere else to put it.
 *
 * Set rather than appended: a path that already carries a `token` would end up
 * with two, and the endpoint reads the first — so the one passed here would be
 * the one ignored. Taken apart by hand rather than through `URL`, which would
 * need a base and would turn a relative path into an absolute one; this keeps
 * whatever shape it was given, absolute url, rooted path or relative.
 * @param {string} path the endpoint, which may already carry a query, a fragment, or both
 * @param {string | undefined} token the token, when the endpoint requires one
 * @returns {string} the endpoint to connect to
 */
export default function withToken(path, token) {
  if (!token) {
    return path;
  }
  var hashAt = path.indexOf("#");
  var hash = hashAt === -1 ? "" : path.slice(hashAt);
  var withoutHash = hashAt === -1 ? path : path.slice(0, hashAt);
  var queryAt = withoutHash.indexOf("?");
  var before = queryAt === -1 ? withoutHash : withoutHash.slice(0, queryAt);
  var query = new URLSearchParams(queryAt === -1 ? "" : withoutHash.slice(queryAt + 1));
  query.set("token", token);

  // Before the fragment, where a query belongs — appending would have put the
  // token inside it.
  return "".concat(before, "?").concat(query).concat(hash);
}