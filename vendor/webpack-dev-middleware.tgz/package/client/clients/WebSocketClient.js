function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function _defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o); } }
function _createClass(e, r, t) { return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
/** @typedef {import("./createSocket.js").CommunicationClient} CommunicationClient */
/** @typedef {import("./createSocket.js").ClientHandler} ClientHandler */

/**
 * `WebSocket` only learned to resolve a relative or `http(s):` url recently —
 * Chrome 125, Firefox 124, Safari 17.3 — and throws a `SyntaxError` on one
 * before that. The default endpoint is a path, so it has to be resolved here
 * or this transport is unusable on every older browser, which are the ones
 * this runtime goes out of its way to support.
 * @param {string} url absolute or relative url
 * @returns {string} an absolute `ws:` or `wss:` url
 */
function toWebSocketURL(url) {
  if (/^wss?:\/\//i.test(url)) {
    return url;
  }

  // An anchor resolves a relative url against the document, and works in
  // browsers older than `URL`. A worker has no document but always has `URL`,
  // so it takes the other path.
  var absolute = typeof document === "undefined" ? new URL(url, self.location.href).href : function () {
    var anchor = document.createElement("a");
    anchor.href = url;
    return anchor.href;
  }();

  // `href` is absolute either way, and its scheme maps one to one onto the
  // WebSocket ones: http to ws, https to wss.
  return absolute.replace(/^http/i, "ws");
}

/**
 * A WebSocket. The browser reports a dropped connection itself, and the server
 * pings to find a half-open one, so unlike Server-Sent Events this needs no
 * watchdog of its own.
 *
 * A failure is not logged here. The `error` event carries no detail by
 * specification, so it would print an opaque object, and it is followed by the
 * `close` the shared socket already reports and acts on — which is also all
 * Server-Sent Events say, so neither transport is noisier than the other.
 * @implements {CommunicationClient}
 */
var WebSocketClient = /*#__PURE__*/function () {
  /**
   * @param {string} url url to connect to
   */
  function WebSocketClient(url) {
    var _this = this;
    _classCallCheck(this, WebSocketClient);
    /** @type {ClientHandler | undefined} */
    this.openHandler = undefined;
    /** @type {ClientHandler | undefined} */
    this.closeHandler = undefined;
    /** @type {ClientHandler | undefined} */
    this.messageHandler = undefined;
    // Set once closed, so an event the socket had already queued cannot report
    // anything after the caller asked for none.
    this.closed = false;
    this.client = new WebSocket(toWebSocketURL(url));
    this.client.onopen = function () {
      if (_this.openHandler) {
        _this.openHandler();
      }
    };
    this.client.onclose = function () {
      if (_this.closed) {
        return;
      }
      if (_this.closeHandler) {
        _this.closeHandler();
      }
    };
    this.client.onmessage = function (event) {
      if (_this.closed) {
        return;
      }
      if (_this.messageHandler) {
        _this.messageHandler(event.data);
      }
    };
  }

  /**
   * @param {ClientHandler} fn called once the connection is open
   */
  return _createClass(WebSocketClient, [{
    key: "onOpen",
    value: function onOpen(fn) {
      this.openHandler = fn;
    }

    /**
     * @param {ClientHandler} fn called once the connection is gone
     */
  }, {
    key: "onClose",
    value: function onClose(fn) {
      this.closeHandler = fn;
    }

    /**
     * @param {ClientHandler} fn called with each message, as a string
     */
  }, {
    key: "onMessage",
    value: function onMessage(fn) {
      this.messageHandler = fn;
    }

    /**
     * Close without reporting it, so the caller does not reconnect.
     */
  }, {
    key: "close",
    value: function close() {
      this.closed = true;
      this.client.close();
    }
  }]);
}();
export { WebSocketClient as default };