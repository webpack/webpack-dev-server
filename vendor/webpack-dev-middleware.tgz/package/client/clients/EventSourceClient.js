function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function _defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o); } }
function _createClass(e, r, t) { return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
/** @typedef {import("./createSocket.js").CommunicationClient} CommunicationClient */
/** @typedef {import("./createSocket.js").ClientHandler} ClientHandler */

// Long enough that a slow build does not look like a dead connection.
var DEFAULT_TIMEOUT = 20 * 1000;

/**
 * Server-Sent Events. A connection can die without the browser firing `error`
 * — a proxy that stops forwarding, a laptop that slept — so this one watches
 * for silence as well, and reports that as a close for the caller to reconnect.
 *
 * A failure is not logged here, for the same reason the WebSocket one does not
 * log it: `error` fires on every routine reconnection, so saying so would be
 * noise rather than news.
 * @implements {CommunicationClient}
 */
var EventSourceClient = /*#__PURE__*/function () {
  /**
   * @param {string} url url to connect to
   * @param {{ timeout?: number }=} options how long silence is tolerated
   */
  function EventSourceClient(url) {
    var _this = this;
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    _classCallCheck(this, EventSourceClient);
    this.timeout = options.timeout || DEFAULT_TIMEOUT;
    /** @type {ClientHandler | undefined} */
    this.openHandler = undefined;
    /** @type {ClientHandler | undefined} */
    this.closeHandler = undefined;
    /** @type {ClientHandler | undefined} */
    this.messageHandler = undefined;
    // Set once closed, so an `error` the EventSource had already queued cannot
    // report a close after the caller asked for none.
    this.closed = false;
    this.lastActivity = Date.now();
    this.client = new self.EventSource(url);
    this.client.addEventListener("open", function () {
      if (_this.closed) {
        return;
      }
      _this.lastActivity = Date.now();
      if (_this.openHandler) {
        _this.openHandler();
      }
    });
    this.client.addEventListener("message", function (event) {
      if (_this.closed) {
        return;
      }
      _this.lastActivity = Date.now();
      if (_this.messageHandler) {
        _this.messageHandler(/** @type {{ data: string }} */event.data);
      }
    });
    this.client.addEventListener("error", function () {
      _this.handleDisconnect();
    });

    // Halved so silence is noticed within one `timeout` rather than two.
    this.timer = setInterval(function () {
      if (Date.now() - _this.lastActivity > _this.timeout) {
        _this.handleDisconnect();
      }
    }, this.timeout / 2);
  }

  /**
   * End this connection and report it, once.
   */
  return _createClass(EventSourceClient, [{
    key: "handleDisconnect",
    value: function handleDisconnect() {
      if (this.closed) {
        return;
      }
      this.close();
      if (this.closeHandler) {
        this.closeHandler();
      }
    }

    /**
     * @param {ClientHandler} fn called once the connection is open
     */
  }, {
    key: "onOpen",
    value: function onOpen(fn) {
      this.openHandler = fn;
    }

    /**
     * @param {ClientHandler} fn called once the connection is gone
     */
  }, {
    key: "onClose",
    value: function onClose(fn) {
      this.closeHandler = fn;
    }

    /**
     * @param {ClientHandler} fn called with each message, as a string
     */
  }, {
    key: "onMessage",
    value: function onMessage(fn) {
      this.messageHandler = fn;
    }

    /**
     * Stop the watchdog and the connection, without reporting a close.
     */
  }, {
    key: "close",
    value: function close() {
      this.closed = true;
      clearInterval(this.timer);
      this.client.close();
    }
  }]);
}();
export { EventSourceClient as default };